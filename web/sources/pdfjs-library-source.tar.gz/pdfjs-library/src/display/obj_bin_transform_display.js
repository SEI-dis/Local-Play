/* Copyright 2025 Mozilla Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
  assert,
  BBOX_INIT,
  FeatureTest,
  shadow,
  Util,
} from "../shared/util.js";
import {
  CSS_FONT_INFO,
  FONT_INFO,
  InfoUtils,
  PATTERN_INFO,
  SYSTEM_FONT_INFO,
} from "../shared/obj_bin_transform_utils.js";

function readString(buffer, view, index, offset = 0) {
  const { decoder } = InfoUtils;
  for (let i = 0; i < index; i++) {
    offset += view.getUint32(offset) + 4;
  }
  const length = view.getUint32(offset);
  return decoder.decode(new Uint8Array(buffer, offset + 4, length));
}

class CssFontInfo {
  #buffer;

  #view;

  constructor(buffer) {
    this.#buffer = buffer;
    this.#view = new DataView(buffer);
  }

  #readString(index) {
    assert(index < CSS_FONT_INFO.strings.length, "Invalid string index");
    return readString(this.#buffer, this.#view, index);
  }

  get fontFamily() {
    return shadow(this, "fontFamily", this.#readString(0));
  }

  get fontWeight() {
    return shadow(this, "fontWeight", this.#readString(1));
  }

  get italicAngle() {
    return shadow(this, "italicAngle", this.#readString(2));
  }
}

class SystemFontInfo {
  #buffer;

  #view;

  constructor(buffer) {
    this.#buffer = buffer;
    this.#view = new DataView(buffer);
  }

  #readString(index) {
    assert(index < SYSTEM_FONT_INFO.strings.length, "Invalid string index");
    return readString(this.#buffer, this.#view, index, /* offset = */ 4);
  }

  get css() {
    return shadow(this, "css", this.#readString(0));
  }

  get loadedName() {
    return shadow(this, "loadedName", this.#readString(1));
  }

  get baseFontName() {
    return shadow(this, "baseFontName", this.#readString(2));
  }

  get src() {
    return shadow(this, "src", this.#readString(3));
  }

  get style() {
    let offset = 0;
    offset += 4 + this.#view.getUint32(offset);
    const style = readString(this.#buffer, this.#view, /* index = */ 0, offset),
      weight = readString(this.#buffer, this.#view, /* index = */ 1, offset);
    return shadow(this, "style", { style, weight });
  }
}

class FontInfo {
  #buffer;

  #view;

  constructor(buffer) {
    this.#buffer = buffer;
    this.#view = new DataView(buffer);
  }

  #readBoolean(index) {
    assert(index < FONT_INFO.bools.length, "Invalid boolean index");
    const byteOffset = Math.floor(index / 4);
    const bitOffset = (index * 2) % 8;
    const value = (this.#view.getUint8(byteOffset) >> bitOffset) & 0x03;
    return value === 0x00 ? undefined : value === 0x02;
  }

  get black() {
    return shadow(this, "black", this.#readBoolean(0));
  }

  get bold() {
    return shadow(this, "bold", this.#readBoolean(1));
  }

  get disableFontFace() {
    return shadow(this, "disableFontFace", this.#readBoolean(2));
  }

  get fontExtraProperties() {
    return shadow(this, "fontExtraProperties", this.#readBoolean(3));
  }

  get isInvalidPDFjsFont() {
    return shadow(this, "isInvalidPDFjsFont", this.#readBoolean(4));
  }

  get isType3Font() {
    return shadow(this, "isType3Font", this.#readBoolean(5));
  }

  get italic() {
    return shadow(this, "italic", this.#readBoolean(6));
  }

  get missingFile() {
    return shadow(this, "missingFile", this.#readBoolean(7));
  }

  get remeasure() {
    return shadow(this, "remeasure", this.#readBoolean(8));
  }

  get vertical() {
    return shadow(this, "vertical", this.#readBoolean(9));
  }

  #readArray(offset, arrLen, lookupName, increment) {
    const len = this.#view.getUint8(offset++);
    if (len === 0) {
      return undefined;
    }
    assert(len === arrLen, "Invalid array length.");
    const arr = new Array(len);
    for (let i = 0; i < len; i++) {
      arr[i] = this.#view[lookupName](offset, true);
      offset += increment;
    }
    return arr;
  }

  get bbox() {
    return shadow(
      this,
      "bbox",
      this.#readArray(
        /* offset = */ FONT_INFO.OFFSET_BBOX,
        /* arrLen = */ 4,
        /* lookup = */ "getInt16",
        /* increment = */ 2
      )
    );
  }

  get fontMatrix() {
    return shadow(
      this,
      "fontMatrix",
      this.#readArray(
        /* offset = */ FONT_INFO.OFFSET_FONT_MATRIX,
        /* arrLen = */ 6,
        /* lookup = */ "getFloat64",
        /* increment = */ 8
      )
    );
  }

  #readString(index) {
    assert(index < FONT_INFO.strings.length, "Invalid string index");
    return readString(
      this.#buffer,
      this.#view,
      index,
      /* offset = */ FONT_INFO.OFFSET_STRINGS + 4
    );
  }

  get fallbackName() {
    return shadow(this, "fallbackName", this.#readString(0));
  }

  get loadedName() {
    return shadow(this, "loadedName", this.#readString(1));
  }

  #getBufferOffset(index) {
    let offset = FONT_INFO.OFFSET_STRINGS;
    // We need to move past any string-data first, hence the `<=` condition.
    for (let i = 0; i <= index; i++) {
      offset += 4 + this.#view.getUint32(offset);
    }
    const length = this.#view.getUint32(offset);

    return { offset, length };
  }

  // NOTE: This cannot be shadowed, since it may be cleared.
  get data() {
    const { offset, length } = this.#getBufferOffset(2);
    return !length
      ? undefined
      : new Uint8Array(this.#buffer, offset + 4, length);
  }

  clearData() {
    const { offset, length } = this.#getBufferOffset(2);
    if (!length) {
      return; // The data is either not present, or it was previously cleared.
    }
    this.#view.setUint32(offset, 0); // Zero the data-length.

    // Replace the buffer/view with only its contents *before* the data-block.
    this.#buffer = new Uint8Array(this.#buffer, 0, offset + 4).slice().buffer;
    this.#view = new DataView(this.#buffer);
  }

  get cssFontInfo() {
    const { offset, length } = this.#getBufferOffset(1);
    let info = null;
    if (length) {
      const data = new Uint8Array(this.#buffer, offset + 4, length).slice();
      info = new CssFontInfo(data.buffer);
    }
    return shadow(this, "cssFontInfo", info);
  }

  get systemFontInfo() {
    const { offset, length } = this.#getBufferOffset(0);
    let info = null;
    if (length) {
      const data = new Uint8Array(this.#buffer, offset + 4, length).slice();
      info = new SystemFontInfo(data.buffer);
    }
    return shadow(this, "systemFontInfo", info);
  }
}

class PatternInfo {
  constructor(buffer) {
    this.buffer = buffer;
    this.view = new DataView(buffer);
    this.data = new Uint8Array(buffer);
  }

  getIR() {
    const dataView = this.view;
    const kind = this.data[PATTERN_INFO.KIND];
    const hasBBox = !!this.data[PATTERN_INFO.HAS_BBOX];
    const hasBackground = !!this.data[PATTERN_INFO.HAS_BACKGROUND];
    const nCoord = dataView.getUint32(PATTERN_INFO.N_COORD, true);
    const nColor = dataView.getUint32(PATTERN_INFO.N_COLOR, true);
    const nStop = dataView.getUint32(PATTERN_INFO.N_STOP, true);

    let offset = 20;
    const coords = new Float32Array(this.buffer, offset, nCoord * 2);
    offset += nCoord * 8;
    const colors = new Uint8Array(this.buffer, offset, nColor * 4);
    offset += nColor * 4;
    const stops = [];
    for (let i = 0; i < nStop; ++i) {
      const p = dataView.getFloat32(offset, true);
      offset += 4;
      const rgb = dataView.getUint32(offset, true);
      offset += 4;
      stops.push([p, `#${rgb.toString(16).padStart(6, "0")}`]);
    }
    let bbox = null;
    if (hasBBox) {
      bbox = [];
      for (let i = 0; i < 4; ++i) {
        bbox.push(dataView.getFloat32(offset, true));
        offset += 4;
      }
    }

    let background = null;
    if (hasBackground) {
      background = new Uint8Array(this.buffer, offset, 3);
      offset += 3;
    }

    if (kind === 1) {
      // axial
      return [
        "RadialAxial",
        "axial",
        bbox,
        stops,
        [coords[0], coords[1]],
        [coords[2], coords[3]],
        null,
        null,
      ];
    }
    if (kind === 2) {
      return [
        "RadialAxial",
        "radial",
        bbox,
        stops,
        [coords[0], coords[1]],
        [coords[3], coords[4]],
        coords[2],
        coords[5],
      ];
    }
    if (kind === 3) {
      const shadingType = this.data[PATTERN_INFO.SHADING_TYPE];
      let bounds = null;
      if (coords.length > 0) {
        bounds = BBOX_INIT.slice();

        for (let i = 0, ii = coords.length; i < ii; i += 2) {
          Util.pointBoundingBox(coords[i], coords[i + 1], bounds);
        }
      }
      return [
        "Mesh",
        shadingType,
        coords,
        colors,
        nCoord,
        bounds,
        bbox,
        background,
      ];
    }
    throw new Error(`Unsupported pattern kind: ${kind}`);
  }
}

class FontPathInfo {
  #buffer;

  constructor(buffer) {
    this.#buffer = buffer;
  }

  get path() {
    if (
      (typeof PDFJSDev !== "undefined" && PDFJSDev.test("MOZCENTRAL")) ||
      FeatureTest.isFloat16ArraySupported
    ) {
      return new Float16Array(this.#buffer);
    }
    return new Float32Array(this.#buffer);
  }
}

export { CssFontInfo, FontInfo, FontPathInfo, PatternInfo, SystemFontInfo };
