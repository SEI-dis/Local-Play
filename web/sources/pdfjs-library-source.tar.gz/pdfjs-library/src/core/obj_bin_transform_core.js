/* Copyright 2025 Mozilla Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { assert, FeatureTest } from "../shared/util.js";
import {
  CSS_FONT_INFO,
  FONT_INFO,
  InfoUtils,
  PATTERN_INFO,
  SYSTEM_FONT_INFO,
} from "../shared/obj_bin_transform_utils.js";

function encodeStrings(strings, obj) {
  const { encoder } = InfoUtils;
  const encodedStrings = new Map();
  let stringsLength = 0;
  for (const prop of strings) {
    const encoded = encoder.encode(obj[prop]),
      len = encoded.length;
    encodedStrings.set(encoded, len);
    stringsLength += 4 + len;
  }
  return { encodedStrings, stringsLength };
}

function writeStrings(encodedStrings, data, view, offset = 0) {
  for (const [encoded, len] of encodedStrings) {
    view.setUint32(offset, len);
    data.set(encoded, offset + 4);
    offset += 4 + len;
  }
  return offset;
}

function compileCssFontInfo(info) {
  const { encodedStrings, stringsLength } = encodeStrings(
    CSS_FONT_INFO.strings,
    info
  );

  const buffer = new ArrayBuffer(stringsLength);
  const data = new Uint8Array(buffer);
  const view = new DataView(buffer);

  const offset = writeStrings(encodedStrings, data, view);
  assert(offset === buffer.byteLength, "compileCssFontInfo: Buffer overflow");
  return buffer;
}

function compileSystemFontInfo(info) {
  const { encodedStrings, stringsLength } = encodeStrings(
    SYSTEM_FONT_INFO.strings,
    info
  );

  let encodedStyleStrings,
    styleStringsLength = 0;
  if (info.style) {
    ({
      encodedStrings: encodedStyleStrings,
      stringsLength: styleStringsLength,
    } = encodeStrings(["style", "weight"], info.style));
  }
  const lengthEstimate = 4 + stringsLength + styleStringsLength;

  const buffer = new ArrayBuffer(lengthEstimate);
  const data = new Uint8Array(buffer);
  const view = new DataView(buffer);
  let offset = 0;

  view.setUint32(offset, stringsLength);
  offset = writeStrings(encodedStrings, data, view, offset + 4);

  if (encodedStyleStrings) {
    offset = writeStrings(encodedStyleStrings, data, view, offset);
  }
  assert(offset <= buffer.byteLength, "compileSystemFontInfo: Buffer overflow");
  return buffer.transferToFixedLength(offset);
}

function compileFontInfo(font) {
  function writeArray(arr, arrLen, writerName, increment) {
    if (arr) {
      view.setUint8(offset++, arrLen);
      for (const val of arr) {
        view[writerName](offset, val, true);
        offset += increment;
      }
    } else {
      view.setUint8(offset++, 0);
      offset += increment * arrLen; // TODO: optimize this padding away
    }
  }
  function writeBuffer(buf, name) {
    if (!buf) {
      view.setUint32(offset, 0);
      offset += 4;
      return;
    }
    const length = buf.byteLength;
    view.setUint32(offset, length);
    assert(
      offset + 4 + length <= buffer.byteLength,
      `compileFontInfo: Buffer overflow at ${name}`
    );
    data.set(new Uint8Array(buf), offset + 4);
    offset += 4 + length;
  }

  const systemFontInfoBuffer = font.systemFontInfo
    ? compileSystemFontInfo(font.systemFontInfo)
    : null;
  const cssFontInfoBuffer = font.cssFontInfo
    ? compileCssFontInfo(font.cssFontInfo)
    : null;

  const { encodedStrings, stringsLength } = encodeStrings(
    FONT_INFO.strings,
    font
  );

  const lengthEstimate =
    FONT_INFO.OFFSET_STRINGS +
    4 +
    stringsLength +
    4 +
    (systemFontInfoBuffer?.byteLength ?? 0) +
    4 +
    (cssFontInfoBuffer?.byteLength ?? 0) +
    4 +
    (font.data?.length ?? 0);

  const buffer = new ArrayBuffer(lengthEstimate);
  const data = new Uint8Array(buffer);
  const view = new DataView(buffer);
  let offset = 0;

  const numBools = FONT_INFO.bools.length;
  let boolByte = 0,
    boolBit = 0;
  for (let i = 0; i < numBools; i++) {
    const value = font[FONT_INFO.bools[i]];
    // eslint-disable-next-line no-nested-ternary
    const bits = value === undefined ? 0x00 : value ? 0x02 : 0x01;
    boolByte |= bits << boolBit;
    boolBit += 2;
    if (boolBit === 8 || i === numBools - 1) {
      view.setUint8(offset++, boolByte);
      boolByte = 0;
      boolBit = 0;
    }
  }
  assert(
    offset === FONT_INFO.OFFSET_BBOX,
    "compileFontInfo: Boolean properties offset mismatch"
  );

  writeArray(
    /* arr = */ font.bbox,
    /* arrLen = */ 4,
    /* writerName = */ "setInt16",
    /* increment = */ 2
  );
  assert(
    offset === FONT_INFO.OFFSET_FONT_MATRIX,
    "compileFontInfo: BBox properties offset mismatch"
  );

  writeArray(
    /* arr = */ font.fontMatrix,
    /* arrLen = */ 6,
    /* writerName = */ "setFloat64",
    /* increment = */ 8
  );
  assert(
    offset === FONT_INFO.OFFSET_STRINGS,
    "compileFontInfo: FontMatrix properties offset mismatch"
  );

  view.setUint32(offset, stringsLength);
  offset = writeStrings(encodedStrings, data, view, offset + 4);

  writeBuffer(systemFontInfoBuffer, "systemFontInfo");
  writeBuffer(cssFontInfoBuffer, "cssFontInfo");

  if (font.data === undefined) {
    view.setUint32(offset, 0);
    offset += 4;
  } else {
    view.setUint32(offset, font.data.length);
    data.set(font.data, offset + 4);
    offset += 4 + font.data.length;
  }

  assert(offset <= buffer.byteLength, "compileFontInfo: Buffer overflow");
  return buffer.transferToFixedLength(offset);
}

function compilePatternInfo(ir) {
  let kind,
    bbox = null,
    coords = [],
    colors = [],
    colorStops = [],
    shadingType = null, // only needed for mesh patterns
    background = null; // background for mesh patterns

  switch (ir[0]) {
    case "RadialAxial":
      kind = ir[1] === "axial" ? 1 : 2;
      bbox = ir[2];
      colorStops = ir[3];
      if (kind === 1) {
        coords.push(...ir[4], ...ir[5]);
      } else {
        coords.push(ir[4][0], ir[4][1], ir[6], ir[5][0], ir[5][1], ir[7]);
      }
      break;
    case "Mesh":
      kind = 3;
      shadingType = ir[1];
      coords = ir[2];
      colors = ir[3];
      bbox = ir[6];
      background = ir[7];
      break;
    default:
      throw new Error(`Unsupported pattern type: ${ir[0]}`);
  }

  const nCoord = Math.floor(coords.length / 2);
  const nColor = Math.floor(colors.length / 4);
  const nStop = colorStops.length;

  const byteLen =
    20 +
    nCoord * 8 +
    nColor * 4 +
    nStop * 8 +
    (bbox ? 16 : 0) +
    (background ? 3 : 0);
  const buffer = new ArrayBuffer(byteLen);
  const dataView = new DataView(buffer);
  const u8data = new Uint8Array(buffer);

  dataView.setUint8(PATTERN_INFO.KIND, kind);
  dataView.setUint8(PATTERN_INFO.HAS_BBOX, bbox ? 1 : 0);
  dataView.setUint8(PATTERN_INFO.HAS_BACKGROUND, background ? 1 : 0);
  dataView.setUint8(PATTERN_INFO.SHADING_TYPE, shadingType); // Only for mesh pattern, null otherwise
  dataView.setUint32(PATTERN_INFO.N_COORD, nCoord, true);
  dataView.setUint32(PATTERN_INFO.N_COLOR, nColor, true);
  dataView.setUint32(PATTERN_INFO.N_STOP, nStop, true);
  dataView.setUint32(PATTERN_INFO.N_FIGURES, 0, true);

  let offset = 20;
  const coordsView = new Float32Array(buffer, offset, nCoord * 2);
  coordsView.set(coords);
  offset += nCoord * 8;

  u8data.set(colors, offset);
  offset += nColor * 4;

  for (const [pos, hex] of colorStops) {
    dataView.setFloat32(offset, pos, true);
    offset += 4;
    dataView.setUint32(offset, parseInt(hex.slice(1), 16), true);
    offset += 4;
  }
  if (bbox) {
    for (const v of bbox) {
      dataView.setFloat32(offset, v, true);
      offset += 4;
    }
  }

  if (background) {
    u8data.set(background, offset);
  }
  return buffer;
}

function compileFontPathInfo(path) {
  if (typeof PDFJSDev === "undefined" || PDFJSDev.test("TESTING")) {
    assert(
      FeatureTest.isFloat16ArraySupported
        ? path instanceof Float16Array
        : path instanceof Float32Array,
      "compileFontPathInfo: Unexpected path format."
    );
  }
  return path.slice().buffer;
}

export {
  compileCssFontInfo,
  compileFontInfo,
  compileFontPathInfo,
  compilePatternInfo,
  compileSystemFontInfo,
};
