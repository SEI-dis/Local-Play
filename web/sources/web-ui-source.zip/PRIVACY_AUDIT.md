# データ保存・通信の確認記録

確認日：2026年10月9日。対象：このWeb配布物。検査には自作のテストプログラムと合成データを使用しています。

## 実装

| 対象 | 保存先・処理 | 確認箇所 |
| --- | --- | --- |
| ROM | IndexedDBのroms。起動時に端末のWASMメモリへコピー | src/app.js、src/storage.js、src/mgba.js、src/retro.js、src/nds.js |
| セーブ、手動ステート、復旧用ステート、履歴 | IndexedDBのsaves、states、recoveries、backups | src/storage.js、src/save-safety.js |
| ライブラリ、画像、スキン | IndexedDBのlibrary、skins。表示用に端末内のdata/blob URLを使用 | src/app.js、src/skins.js |
| カバー画像 | IndexedDBのlibrary。端末内の画像をdata URLに変換 | src/cover-dialog.js |
| 設定 | localStorageのmanic-settings。ROM・セーブのバイト列は保存しない | src/app.js |
| オフライン用アプリ | Cache Storage。配布マニフェスト内の静的ファイルだけを保存 | sw.js、offline-manifest.js |
| ゲーム実行 | 端末内のWASM・Canvas・Web Audio | src/mgba.js、src/retro.js、src/video.js |
| ユーザーによるセーブ等の書き出し | Blobから端末へのダウンロード。ROMの共有・書き出し機能は実装しない | src/app.jsのdownload、src/game-info.jsのexportSave |

OPFS・sessionStorageは利用していません。「IndexedDBだけ」はアプリによるROM・セーブの
永続保存先についての説明です。実行中のメモリや、明示的に書き出したファイルは別です。

## カバー画像

端末内のPNG・JPEG・WebPを選び、最大512pxへ縮小してIndexedDBへ保存します。外部画像の検索・
自動取得コードと取得先のCSP／Service Worker例外を除去しました。旧autoCovers設定がオンでも
通信は行わず、設定を破棄します。既存の画像データと旧coverCatalogsストアは削除しません。
旧画像のURLから再取得する処理はありません。

## 通信する場合

- 初回表示、未取得コアの初回起動、オフライン保存、更新時は、同じ配信元からアプリの
  HTML・JavaScript・WASMなどを取得します。更新確認だけに限った通信ではありません。
- ROMファイルをOSの共有画面へ渡す処理と、ROMを書き出す処理は削除しました。起動リンクはURLのフラグメントにローカルのゲームIDだけを含み、ROM本体を含みません。フラグメントはサーバーへ送信しません。
- 自動アップロード、解析、広告、クラウドセーブ、ROM取得サービスは実装していません。
  コアの生成JSにはバイナリ取得用のGET処理があります。ロード先は同じサイトの固定コアパスです。
- PDFスキンはローカルのバイト列から処理します。PDF.jsも同梱し、外部フォント取得や
  workerによるリソース取得を無効にしています。実行可能なPDFスクリプトは実行しません。
- 作者・ライセンス・スキン案内の外部リンクを利用者が開くと、そのサイトへ移動します。
  アプリはROM・セーブをリンクに付加せず、referrerも送らない設定です。
- 「部屋を作る」「参加」を押した場合だけ、固定のCelio中継先
  wss://celio-server.up.railway.app/socket.io/ にWebSocketで接続します。
  通常プレイ・通信画面の表示・番号入力だけでは接続しません。
- 送るのはランダムな接続ID、部屋操作、状態、32個の16-bitシリアル値です。
  ROM名・ハッシュ・ROMバイト列・セーブファイルを読み出すAPIは通信モジュールにありません。
  ただしプレイヤー情報や交換内容など、ゲームがケーブル通信へ出す情報はサーバーと相手へ届きます。
  サーバー側にはIPアドレスも伝わります。部屋番号は認証パスワードではありません。
- 中継サーバーの運営・ログ保存方針・可用性は本アプリでは管理できません。
  利用者が通信を明示的に開始する場面だけの例外として、画面にも接続先と送信内容を説明しています。
- 旧WebRTCモジュールは既存の独立したプロトコルテスト用に残していますが、アプリのUIからは
  呼び出しません。通常の通信プレイでGoogle STUNやTURNは使用しません。

通信プレイや外部リンクを利用しない通常のプレイでは、同じ配信元からアプリの静的ファイルを取得するだけです。

## 送信防止の補強と限界

- HTMLのCSPはconnect-srcを同一配信元・blob・固定WSS接続先に限定し、フォーム送信を禁止しています。
- Service Worker管理下のページでは、GET/HEAD以外を405で拒否します。ページ遷移以外の
  別配信元またはクエリ付きリクエストも403で拒否します。外部画像の例外はありません。
- 開発用サーバーscripts/serve.cjsはGET/HEAD専用です。アップロード先・書き込み先・
  リクエスト内容を記録するルートはありません。GitHub Pages用ワークフローは静的配信のみです。
- Service Worker未管理の初回読み込みにはその防止処理は働きません。CSPはHTTPメソッドを
  制限する仕組みではありません。WebSocketはService Workerのfetch検査対象外です。
  通信モジュールの入力・送信経路と実際の送信内容を併せて検査します。
- 利用者が改変したコード、ブラウザ拡張、端末侵害、将来の更新まで保証するものではありません。
  localhostの実行中サーバーには再起動後、新しいPWA処理にはアプリ更新後に変更が反映されます。

## 検証方法

tests/privacy.cjsは専用ブラウザと専用ループバックサーバーを起動し、合成ROMだけで確認します。カバーの外部検索・取得機能はありません。tests/covers.cjsでは過去の自動取得設定が残っていても通信しないことを検査します。

1. インポート、プレイ、手動ステート保存・読み込み、ゲーム内セーブの書き出し・読み込み、終了。
2. IndexedDBに保存された内容の一致。localStorage/sessionStorage/Cache Storageへの混入がないこと。
3. 通常操作のHTTPが同一配信元のGET/HEADで、本文・クエリ・私的なファイル名を含まないこと。
4. 通常操作ではWebSocket・WebRTC接続が生成されないこと。
5. 無害な文字列によるPOST/PUT/PATCH/DELETEとクエリ送信の試験。
   Service Workerで止まり、サーバーに届かないこと。開発用サーバー側でも書き込みを拒否すること。

tests/browser.cjsはGBA 64MiBを含む6機種で起動・保存とHTTP記録を検査します。
tests/features.cjsはオフライン再起動、tests/update.cjsは更新時のセーブ維持、
tests/room-link.cjsは合成ゲームと固定版のliru55公開コア・通信処理を組み合わせ、Celio部屋方式の
相互接続・切断復旧・正常終了を検査します。tests/link.cjsは旧プロトコル単体の回帰検査です。
配布前にはcheck-releaseでROM/セーブ混入、対応ソース、通知と固定ハッシュを確認します。

通常通信の検査と変更した通信機能の結果は LINK_COMPATIBILITY.md に記録しています。
通信画面の表示や部屋番号の入力だけで接続しないことも検査対象です。
WebKitのPC用テストであり、iPhone実機の検査ではありません。

## 法律上の整理

サーバーへ送らない設計は、ファイルの入手・複製・改変・利用に関する権利を与えません。
この検査は特定ROMの適法性を認定するものではありません。
ROM・BIOS・第三者のスキンは配布物やリポジトリへ入れず、コードについては
LICENSE_AUDIT.mdに記載したライセンス通知・対応ソースを維持します。

参考：[文化庁・著作権の相談とFAQ](https://www.bunka.go.jp/seisaku/chosakuken/kaizoku/contact.html)。
個別の配布・利用について判断が必要な場合は、権利者の許諾確認と専門家の確認が必要です。

2026年10月9日追記：NDS用WASMの取得先も同じ配信元です。nds-browser.cjsで
2画面・タッチ・ステート・セーブのインポートと再起動をEdgeとPC版WebKitで検査し、
同一配信元のGET/HEAD以外を発生させないことを確認しました。NDSのWi-Fi機能はUIに公開しません。

2026年10月9日追記：tests/covers.cjsで合成画像を使い、端末内の画像選択と保存、再読み込み、
不正な画像の拒否、カバー変更時のROM・セーブ保持、過去の設定から外部取得が復活しないことを検査します。
追加コアも同一配信元の静的ファイルだけを取得します。tests/multicore.cjsは全7機種の追加コアを
合成ROMで起動し、コアごとの保存先・タブ間のロック・削除・HTTP通信の範囲を確認します。
