// SPDX-License-Identifier: AGPL-3.0-or-later
use wasm_bindgen::prelude::*;
use bincode::{Decode, Encode};
use std::collections::BTreeMap;
use jgenesis_common::frontend::{AudioOutput, Color, ConstantInputPoller, EmulatorTrait,
    FrameSize, MappableInputs, Renderer, RenderFrameOptions, SaveWriter, TickEffect};
use jgenesis_common::input::Player;
use genesis_core::api::{GenesisEmulator, GenesisHardware};
use gb_core::api::{GameBoyEmulator, GameBoyEmulatorConfig, BootRoms};
use nes_core::api::NesEmulator;
use snes_core::api::{SnesEmulator, CoprocessorRoms};

fn config() -> impl bincode::config::Config {
    bincode::config::standard().with_little_endian().with_fixed_int_encoding().with_limit::<{64*1024*1024}>()
}
fn error(e: impl std::fmt::Display) -> JsValue { JsValue::from_str(&e.to_string()) }
fn encode<T: Encode>(value: T) -> Result<Vec<u8>, JsValue> { bincode::encode_to_vec(value,config()).map_err(error) }
fn decode<T: Decode<()>>(bytes: &[u8]) -> Result<T, JsValue> {
    if bytes.len()>64*1024*1024 {return Err(error("Data too large"));}
    let (value,used)=bincode::decode_from_slice(bytes,config()).map_err(error)?;
    if used!=bytes.len() {return Err(error("Unexpected trailing data"));} Ok(value)
}
#[derive(Default)]
struct Video {pixels:Vec<Color>,width:u32,height:u32,fps:f64}
impl Renderer for Video {
    type Err=String;
    fn render_frame(&mut self,pixels:&[Color],size:FrameSize,fps:f64,_:RenderFrameOptions)->Result<(),String>{
        if size.width>1024||size.height>1024{return Err("Unsupported video size".into());}
        self.pixels.clear();self.pixels.extend_from_slice(&pixels[..size.len() as usize]);
        self.width=size.width;self.height=size.height;self.fps=fps;Ok(())
    }
}
#[derive(Default)]
struct Audio {samples:Vec<i16>}
impl AudioOutput for Audio {
    type Err=String;
    fn push_sample(&mut self,l:f64,r:f64)->Result<(),String>{
        if self.samples.len()>=32768{return Err("Audio frame overflow".into());}
        self.samples.push((l.clamp(-1.0,1.0)*32767.0) as i16);
        self.samples.push((r.clamp(-1.0,1.0)*32767.0) as i16);Ok(())
    }
}
#[derive(Default,Encode,Decode)]
struct Saves {files:BTreeMap<String,Vec<u8>>}
impl SaveWriter for Saves {
    type Err=String;
    fn load_bytes(&mut self,ext:&str)->Result<Vec<u8>,String>{self.files.get(ext).cloned().ok_or("No save".into())}
    fn persist_bytes(&mut self,ext:&str,bytes:&[u8])->Result<(),String>{
        if bytes.len()>4*1024*1024{return Err("Save too large".into());}
        self.files.insert(ext.to_owned(),bytes.to_vec());Ok(())
    }
    fn load_serialized<D:Decode<()>>(&mut self,ext:&str)->Result<D,String>{
        let data=self.load_bytes(ext)?;bincode::decode_from_slice(&data,config()).map(|(v,_)|v).map_err(|e|e.to_string())
    }
    fn persist_serialized<E:Encode>(&mut self,ext:&str,value:E)->Result<(),String>{
        let bytes=bincode::encode_to_vec(value,config()).map_err(|e|e.to_string())?;self.persist_bytes(ext,&bytes)
    }
}
enum Core {Md(GenesisEmulator),Gb(GameBoyEmulator),Nes(NesEmulator),Snes(SnesEmulator)}
macro_rules! each {($core:expr,$e:ident,$body:expr)=>{match $core {Core::Md($e)=>$body,Core::Gb($e)=>$body,Core::Nes($e)=>$body,Core::Snes($e)=>$body}};}
fn run_frame<E:EmulatorTrait>(core:&mut E,inputs:E::Inputs,video:&mut Video,audio:&mut Audio,saves:&mut Saves)->Result<(),JsValue>{
    let mut poller=ConstantInputPoller(&inputs);
    for _ in 0..2_000_000 {
        if core.tick(video,audio,&mut poller,saves).map_err(error)?==TickEffect::FrameRendered{return Ok(());}
    }Err(error("Core did not finish a frame"))
}
fn inputs<I:MappableInputs<B>+Default,B:Copy>(mask:u32,mapping:&[(u32,B)])->I{
    let mut inputs=I::default();for &(bit,key) in mapping {inputs.set_field(key,Player::One,mask&(1<<bit)!=0);}inputs
}
#[derive(Encode,Decode)]
struct Snapshot {version:u32,system:u32,core:Vec<u8>,saves:Saves}
#[wasm_bindgen]
pub struct Game {system:u32,core:Core,video:Video,audio:Audio,saves:Saves}
#[wasm_bindgen]
impl Game {
    #[wasm_bindgen(constructor)]
    pub fn new(system:u32,rom:&[u8],save:&[u8])->Result<Game,JsValue>{
        if rom.len()>64*1024*1024||rom.len()<512{return Err(error("Invalid ROM size"));}
        let mut saves=if save.is_empty(){Saves::default()}else{Self::parse_save(save)?};
        let mut core=match system {
            0=>Core::Md(GenesisEmulator::create(GenesisHardware::Standalone,Some(rom.to_vec()),None,None,Default::default(),&mut saves).map_err(error)?),
            1|2=>Core::Gb(GameBoyEmulator::create(rom.to_vec(),BootRoms{dmg:None,cgb:None},GameBoyEmulatorConfig{
                force_dmg_mode:false,force_cgb_mode:false,pretend_to_be_gba:false,
                aspect_ratio:Default::default(),gb_palette:Default::default(),gb_custom_palette:[(0,0,0);4],
                gbc_color_correction:Default::default(),frame_blending:false,audio_resampler:Default::default(),
                audio_60hz_hack:false,allow_opposing_joypad_directions:false
            },&mut saves).map_err(error)?),
            3=>Core::Nes(NesEmulator::create(rom.to_vec(),nes_core::api::NesEmulatorConfig{
                forced_timing_mode:None,aspect_ratio:Default::default(),palette:Default::default(),
                ntsc_crop_vertical_overscan:false,overscan:Default::default(),emulate_ntsc_output:false,
                remove_sprite_limit:false,pal_black_border:false,silence_ultrasonic_triangle_output:false,
                audio_resampler:Default::default(),audio_refresh_rate_adjustment:false,
                allow_opposing_joypad_directions:false,dma_dummy_joy_reads:true
            },&mut saves).map_err(error)?),
            4=>Core::Snes(SnesEmulator::create(rom.to_vec(),Default::default(),CoprocessorRoms::none(),&mut saves).map_err(error)?),
            _=>return Err(error("Unsupported system"))
        };
        each!(&mut core,e,e.update_audio_output_frequency(48000));
        let mut video=Video::default();each!(&mut core,e,e.force_render(&mut video).map_err(error))?;
        Ok(Game{system,core,video,audio:Audio::default(),saves})
    }
    pub fn frame(&mut self,keys:u32)->Result<(),JsValue>{
        self.audio.samples.clear();
        match &mut self.core {
            Core::Md(e)=>{use genesis_config::GenesisButton::*;run_frame(e,inputs(keys,&[(0,A),(1,B),(3,Start),(4,Right),(5,Left),(6,Up),(7,Down),(8,Z),(9,Y),(10,X),(11,Y),(12,C),(13,Z)]),&mut self.video,&mut self.audio,&mut self.saves)},
            Core::Gb(e)=>{use gb_config::GameBoyButton::*;run_frame(e,inputs(keys,&[(0,A),(1,B),(2,Select),(3,Start),(4,Right),(5,Left),(6,Up),(7,Down)]),&mut self.video,&mut self.audio,&mut self.saves)},
            Core::Nes(e)=>{use nes_config::NesButton::*;run_frame(e,inputs(keys,&[(0,A),(1,B),(2,Select),(3,Start),(4,Right),(5,Left),(6,Up),(7,Down)]),&mut self.video,&mut self.audio,&mut self.saves)},
            Core::Snes(e)=>{use snes_config::SnesButton::*;run_frame(e,inputs(keys,&[(0,A),(1,B),(2,Select),(3,Start),(4,Right),(5,Left),(6,Up),(7,Down),(8,R),(9,L),(10,X),(11,Y)]),&mut self.video,&mut self.audio,&mut self.saves)},
        }
    }
    pub fn pixels_ptr(&self)->usize{self.video.pixels.as_ptr() as usize}
    pub fn width(&self)->u32{self.video.width}
    pub fn height(&self)->u32{self.video.height}
    pub fn fps(&self)->f64{each!(&self.core,e,e.target_fps())}
    pub fn audio_ptr(&self)->usize{self.audio.samples.as_ptr() as usize}
    pub fn audio_len(&self)->usize{self.audio.samples.len()/2}
    pub fn reset(&mut self){each!(&mut self.core,e,e.soft_reset());self.audio.samples.clear();}
    pub fn state(&self)->Result<Vec<u8>,JsValue>{
        let core=each!(&self.core,e,encode(e.to_save_state()))?;
        // Round trip to copy the small sidecar map without requiring core clones.
        encode(Snapshot{version:1,system:self.system,core,saves:decode(&encode(&self.saves)?)?})
    }
    pub fn load_state(&mut self,bytes:&[u8])->Result<(),JsValue>{
        let snapshot:Snapshot=decode(bytes)?;
        if snapshot.version!=1||snapshot.system!=self.system{return Err(error("State belongs to another core or system"));}
        // Decode completely before changing the live emulator.
        each!(&mut self.core,e,{let saved=decode(&snapshot.core)?;e.load_state(saved);});
        self.saves=snapshot.saves;self.audio.samples.clear();each!(&mut self.core,e,e.force_render(&mut self.video).map_err(error))
    }
    pub fn save(&mut self)->Result<Vec<u8>,JsValue>{
        each!(&mut self.core,e,e.web_flush_save(&mut self.saves).map_err(error))?;
        if self.saves.files.is_empty(){return Ok(vec![]);}
        let mut bytes=b"LPJGSV01".to_vec();bytes.extend_from_slice(&encode(&self.saves)?);Ok(bytes)
    }
}
impl Game {
    fn parse_save(bytes:&[u8])->Result<Saves,JsValue>{
        if bytes.len()>4*1024*1024{return Err(error("Save too large"));}
        if let Some(payload)=bytes.strip_prefix(b"LPJGSV01"){decode(payload)}
        else {let mut saves=Saves::default();saves.files.insert("sav".into(),bytes.to_vec());Ok(saves)}
    }
}
