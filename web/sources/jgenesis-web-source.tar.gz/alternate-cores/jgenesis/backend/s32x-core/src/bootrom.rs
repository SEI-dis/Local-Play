pub type M68kVectors = [u8; 256];

// Modified for Local Play Web 2026-10-09. GPL-3.0.
// The Web wrapper supports GenesisHardware::Standalone only. No 32X boot
// firmware is included in this distribution or its corresponding source.
pub const SH2_MASTER: &[u8; 2048] = &[0; 2048];
pub const SH2_SLAVE: &[u8; 1024] = &[0; 1024];

const M68K_VECTORS: &M68kVectors = &[0; 256];

pub const fn new_m68k_vectors() -> M68kVectors {
    let mut vectors = *M68K_VECTORS;

    // 68K HINT vector is initialized to 0 - verified on hardware by testpico
    vectors[0x70] = 0;
    vectors[0x71] = 0;
    vectors[0x72] = 0;
    vectors[0x73] = 0;

    vectors
}
