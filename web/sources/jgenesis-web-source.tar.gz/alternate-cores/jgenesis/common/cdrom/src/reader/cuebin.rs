//! Code for loading and reading CD-ROM images in CUE/BIN format

#[cfg(test)]
mod tests;

use crate::cdtime::CdTime;
use crate::cue::{CueSheet, Track, TrackMode};
use crate::reader::{SECTOR_HEADER_LEN, synthesize_data_header};
use crate::{CdRomError, CdRomResult, cue};
use bincode::{Decode, Encode};
use regex::Regex;
use std::collections::{HashMap, HashSet};
use std::fs::File;
use std::io::{BufReader, Read, Seek, SeekFrom};
use std::path::Path;
use std::str::FromStr;
use std::sync::LazyLock;
use std::{env, fs, io, mem};

#[derive(Debug, Clone, Encode, Decode)]
pub struct TrackMetadata {
    pub file_name: String,
    pub mode: TrackMode,
    pub address_in_file: u64,
}

#[derive(Debug)]
struct CdRomFile<F: Read + Seek> {
    file: BufReader<F>,
    position: u64,
}

impl<F: Read + Seek> CdRomFile<F> {
    fn new(file: F) -> Self {
        Self { file: BufReader::new(file), position: 0 }
    }
}

#[derive(Debug)]
pub struct CdBinFiles<F: Read + Seek> {
    files: HashMap<String, CdRomFile<F>>,
    track_metadata: Vec<TrackMetadata>,
}

impl<F: Read + Seek> CdBinFiles<F> {
    pub fn empty() -> Self {
        Self { files: HashMap::new(), track_metadata: Vec::new() }
    }

    pub fn create<OpenFn, P: AsRef<Path>>(
        cue_path: P,
        bin_open_fn: OpenFn,
    ) -> CdRomResult<(Self, CueSheet)>
    where
        OpenFn: for<'a> Fn(&'a Path) -> io::Result<F>,
    {
        let cue_path = cue_path.as_ref();

        let (cue_sheet, track_metadata) = parse_cue(cue_path)?;

        let file_names: HashSet<_> =
            track_metadata.iter().map(|metadata| metadata.file_name.clone()).collect();

        let parent_dir = cue_path
            .parent()
            .ok_or_else(|| CdRomError::CueParentDir(cue_path.display().to_string()))?;

        let mut files = HashMap::with_capacity(file_names.len());
        for file_name in file_names {
            let file_path = parent_dir.join(Path::new(&file_name));
            let file = bin_open_fn(&file_path).map_err(|source| CdRomError::BinOpen {
                path: file_path.display().to_string(),
                source,
            })?;
            files.insert(file_name, CdRomFile::new(file));
        }

        let bin_files = Self { files, track_metadata };
        Ok((bin_files, cue_sheet))
    }

    pub fn read_sector(
        &mut self,
        track_number: u8,
        absolute_time: CdTime,
        relative_sector_number: u32,
        out: &mut [u8],
    ) -> CdRomResult<()> {
        let metadata = &self.track_metadata[(track_number - 1) as usize];
        let CdRomFile { file: track_file, position } = self
            .files
            .get_mut(&metadata.file_name)
            .expect("Track file was not opened on load; this is a bug");

        let sector_addr = metadata.address_in_file
            + u64::from(relative_sector_number) * metadata.mode.bytes_per_sector();

        // Only seek if the file descriptor is not already at the desired position
        if *position != sector_addr {
            track_file.seek(SeekFrom::Start(sector_addr)).map_err(CdRomError::DiscReadIo)?;
        }

        match metadata.mode {
            TrackMode::Mode1DataOnly => {
                // 2048-byte sectors
                out[..SECTOR_HEADER_LEN as usize]
                    .copy_from_slice(&synthesize_data_header(metadata.mode, absolute_time));
                track_file
                    .read_exact(
                        &mut out[SECTOR_HEADER_LEN as usize..(SECTOR_HEADER_LEN + 2048) as usize],
                    )
                    .map_err(CdRomError::DiscReadIo)?;
                out[(SECTOR_HEADER_LEN + 2048) as usize..crate::BYTES_PER_SECTOR as usize].fill(0);

                *position = sector_addr + 2048;
            }
            TrackMode::Mode1 | TrackMode::Mode2 | TrackMode::Audio => {
                track_file
                    .read_exact(&mut out[..crate::BYTES_PER_SECTOR as usize])
                    .map_err(CdRomError::DiscReadIo)?;
                *position = sector_addr + crate::BYTES_PER_SECTOR;
            }
        }

        Ok(())
    }
}

#[derive(Debug, Clone)]
#[cfg_attr(test, derive(PartialEq, Eq))]
struct ParsedTrack {
    number: u8,
    mode: TrackMode,
    pregap_len: Option<CdTime>,
    pause_start: Option<CdTime>,
    postgap_len: Option<CdTime>,
    track_start: CdTime,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum FileType {
    Binary,
    Wave,
}

impl FromStr for FileType {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "BINARY" => Ok(Self::Binary),
            "WAVE" => Ok(Self::Wave),
            _ => Err(format!("unrecognized FILE type: {s}")),
        }
    }
}

#[derive(Debug, Clone)]
#[cfg_attr(test, derive(PartialEq, Eq))]
struct ParsedFile {
    file_name: String,
    file_type: FileType,
    tracks: Vec<ParsedTrack>,
}

#[derive(Debug, Clone)]
struct CueParser {
    files: Vec<ParsedFile>,
    tracks: Vec<ParsedTrack>,
    current_file: Option<(String, FileType)>,
    current_track: Option<(u8, TrackMode)>,
    last_track_number: Option<u8>,
    pregap_len: Option<CdTime>,
    pause_start: Option<CdTime>,
    postgap_len: Option<CdTime>,
    track_start: Option<CdTime>,
}

impl CueParser {
    fn new() -> Self {
        Self {
            files: vec![],
            tracks: vec![],
            current_file: None,
            current_track: None,
            last_track_number: None,
            pregap_len: None,
            pause_start: None,
            postgap_len: None,
            track_start: None,
        }
    }

    fn parse(mut self, file: &str) -> CdRomResult<Vec<ParsedFile>> {
        for line in file.lines() {
            let trimmed = line.trim_start();
            if trimmed.starts_with("FILE ") {
                self.parse_file_line(line)?;
            } else if trimmed.starts_with("TRACK ") {
                self.parse_track_line(line)?;
            } else if trimmed.starts_with("INDEX ") {
                self.parse_index_line(line)?;
            } else if trimmed.starts_with("PREGAP ") {
                self.parse_pregap_line(line)?;
            } else if trimmed.starts_with("POSTGAP ") {
                self.parse_postgap_line(line)?;
            }
        }

        self.push_file()?;

        if self.files.is_empty() {
            return Err(CdRomError::CueParse("CUE file has no tracks".into()));
        }

        Ok(self.files)
    }

    #[allow(clippy::items_after_statements)]
    fn parse_file_line(&mut self, line: &str) -> CdRomResult<()> {
        self.push_file()?;

        static RE: LazyLock<Regex> =
            LazyLock::new(|| Regex::new(r#"FILE "(.*)" ([^ ]*)"#).unwrap());

        let captures =
            RE.captures(line).ok_or_else(|| CdRomError::CueInvalidFileLine(line.into()))?;
        let file_name = captures.get(1).unwrap();
        let file_type = captures
            .get(2)
            .unwrap()
            .as_str()
            .parse::<FileType>()
            .map_err(|_| CdRomError::CueInvalidFileLine(line.into()))?;

        self.current_file = Some((file_name.as_str().into(), file_type));

        Ok(())
    }

    #[allow(clippy::items_after_statements)]
    fn parse_track_line(&mut self, line: &str) -> CdRomResult<()> {
        self.push_track()?;

        static RE: LazyLock<Regex> =
            LazyLock::new(|| Regex::new(r"TRACK ([^ ]*) ([^ ]*)").unwrap());

        let captures =
            RE.captures(line).ok_or_else(|| CdRomError::CueInvalidTrackLine(line.into()))?;
        let track_number = captures
            .get(1)
            .unwrap()
            .as_str()
            .parse::<u8>()
            .map_err(|_| CdRomError::CueInvalidTrackLine(line.into()))?;
        let mode = captures
            .get(2)
            .unwrap()
            .as_str()
            .parse::<TrackMode>()
            .map_err(|_| CdRomError::CueInvalidTrackLine(line.into()))?;

        self.current_track = Some((track_number, mode));

        Ok(())
    }

    fn parse_index_line(&mut self, line: &str) -> CdRomResult<()> {
        static RE: LazyLock<Regex> =
            LazyLock::new(|| Regex::new(r"INDEX ([^ ]*) ([^ ]*)").unwrap());

        let captures =
            RE.captures(line).ok_or_else(|| CdRomError::CueInvalidIndexLine(line.into()))?;
        let index_number = captures.get(1).unwrap();
        let start_time = captures
            .get(2)
            .unwrap()
            .as_str()
            .parse::<CdTime>()
            .map_err(|_| CdRomError::CueInvalidIndexLine(line.into()))?;

        match index_number.as_str() {
            "00" => {
                self.pause_start = Some(start_time);
            }
            "01" => {
                self.track_start = Some(start_time);
            }
            _ => {
                return Err(CdRomError::CueInvalidIndexLine(line.into()));
            }
        }

        Ok(())
    }

    fn parse_pregap_line(&mut self, line: &str) -> CdRomResult<()> {
        static RE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"PREGAP ([^ ]*)").unwrap());

        let captures =
            RE.captures(line).ok_or_else(|| CdRomError::CueInvalidPregapLine(line.into()))?;
        let pregap_len = captures
            .get(1)
            .unwrap()
            .as_str()
            .parse::<CdTime>()
            .map_err(|_| CdRomError::CueInvalidPregapLine(line.into()))?;

        self.pregap_len = Some(pregap_len);

        Ok(())
    }

    fn parse_postgap_line(&mut self, line: &str) -> CdRomResult<()> {
        static RE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"POSTGAP ([^ ]*)").unwrap());

        let captures =
            RE.captures(line).ok_or_else(|| CdRomError::CueInvalidPregapLine(line.into()))?;
        let postgap_len = captures
            .get(1)
            .unwrap()
            .as_str()
            .parse::<CdTime>()
            .map_err(|_| CdRomError::CueInvalidPostgapLine(line.into()))?;

        self.postgap_len = Some(postgap_len);

        Ok(())
    }

    fn push_file(&mut self) -> CdRomResult<()> {
        self.push_track()?;

        let Some((file_name, file_type)) = self.current_file.take() else { return Ok(()) };

        if self.tracks.is_empty() {
            return Err(CdRomError::CueParse(format!("No tracks listed for file '{file_name}'")));
        }

        self.files.push(ParsedFile { file_name, file_type, tracks: mem::take(&mut self.tracks) });

        Ok(())
    }

    fn push_track(&mut self) -> CdRomResult<()> {
        let Some((track_number, track_mode)) = self.current_track.take() else {
            return Ok(());
        };

        match self.last_track_number {
            None => {
                if track_number != 1 {
                    return Err(CdRomError::CueParse(format!(
                        "Expected first track to be 01, was {track_number}"
                    )));
                }
            }
            Some(last_track_number) => {
                if track_number != last_track_number + 1 {
                    return Err(CdRomError::CueParse(format!(
                        "Tracks out of order; track {track_number} after {last_track_number}"
                    )));
                }
            }
        }
        self.last_track_number = Some(track_number);

        let Some(track_start) = self.track_start.take() else {
            return Err(CdRomError::CueParse(format!(
                "No start time found for track {track_number}"
            )));
        };

        self.tracks.push(ParsedTrack {
            number: track_number,
            mode: track_mode,
            pregap_len: self.pregap_len.take(),
            pause_start: self.pause_start.take(),
            postgap_len: self.postgap_len.take(),
            track_start,
        });

        Ok(())
    }
}

fn parse_cue<P: AsRef<Path>>(cue_path: P) -> CdRomResult<(CueSheet, Vec<TrackMetadata>)> {
    let cue_path = cue_path.as_ref();

    let cue_file = fs::read_to_string(cue_path)
        .map_err(|source| CdRomError::CueOpen { path: cue_path.display().to_string(), source })?;
    let parsed_files = CueParser::new().parse(&cue_file)?;

    to_cue_sheet(parsed_files, cue_path)
}

const WAVE_HEADER_LEN: u64 = 44;

fn to_cue_sheet(
    parsed_files: Vec<ParsedFile>,
    cue_path: &Path,
) -> CdRomResult<(CueSheet, Vec<TrackMetadata>)> {
    let cue_parent_dir = cue_path
        .parent()
        .ok_or_else(|| CdRomError::CueParentDir(cue_path.display().to_string()))?;

    let mut absolute_start_time = CdTime::ZERO;
    let mut tracks = Vec::new();
    let mut track_metadata = Vec::new();

    for ParsedFile { file_name, file_type, tracks: parsed_tracks } in parsed_files {
        let bin_path = cue_parent_dir.join(&file_name);

        let file_metadata = fs::metadata(&bin_path).map_err(|source| CdRomError::FsMetadata {
            path: bin_path.display().to_string(),
            source,
        })?;

        if file_type == FileType::Wave {
            validate_wav_header(&bin_path, &file_metadata)?;
        }

        let mut address_in_file = match file_type {
            FileType::Binary => 0,
            FileType::Wave => WAVE_HEADER_LEN,
        };

        for i in 0..parsed_tracks.len() {
            let track = &parsed_tracks[i];

            let track_type = track.mode.to_type();
            let pregap_len = match track.number {
                1 => {
                    // Track 1 always has a 2-second pregap; 00:02:00 should be first user data sector of track 1
                    CdTime::new(0, 2, 0)
                }
                _ => track.pregap_len.unwrap_or(CdTime::ZERO),
            };
            let pause_len = track
                .pause_start
                .map_or(CdTime::ZERO, |pause_start| track.track_start - pause_start);

            let start_time_in_file = track.pause_start.unwrap_or(track.track_start);
            let is_first_track_in_file = i == 0;
            if is_first_track_in_file {
                address_in_file += u64::from(start_time_in_file.to_sector_number())
                    * track.mode.bytes_per_sector();
            }

            let is_last_track_in_file = i == parsed_tracks.len() - 1;
            let data_end_time = if is_last_track_in_file {
                let file_len_bytes = file_metadata.len();
                let track_len_bytes = file_len_bytes - address_in_file;
                let track_len_sectors = track_len_bytes / track.mode.bytes_per_sector();

                start_time_in_file + CdTime::from_sector_number(track_len_sectors as u32)
            } else {
                let next_track = &parsed_tracks[i + 1];
                next_track.pause_start.unwrap_or(next_track.track_start)
            };

            let postgap_len = track.postgap_len.unwrap_or(CdTime::ZERO);

            let padded_track_len =
                pregap_len + pause_len + (data_end_time - track.track_start) + postgap_len;
            tracks.push(Track {
                number: track.number,
                mode: track.mode,
                track_type,
                start_time: absolute_start_time,
                end_time: absolute_start_time + padded_track_len,
                pregap_len,
                pause_len,
                postgap_len,
            });
            track_metadata.push(TrackMetadata {
                file_name: file_name.clone(),
                mode: track.mode,
                address_in_file,
            });

            absolute_start_time += padded_track_len;

            let track_len_sectors = (data_end_time - start_time_in_file).to_sector_number();
            address_in_file += u64::from(track_len_sectors) * track.mode.bytes_per_sector();
        }
    }

    cue::finalize_track_list(&mut tracks);

    // This is gross but I don't want cdrom to depend on env_logger just for the validator tool
    if env::var("JGENESIS_PRINT_CUE").is_ok_and(|var| !var.is_empty()) {
        println!("Parsed cue sheet:\n{tracks:#?}");
    } else {
        log::debug!("Parsed cue sheet:\n{tracks:#?}");
    }

    assert!(
        cue::tracks_are_continuous(&tracks),
        "Tracks in parsed CUE sheet are not continuous; this is a bug"
    );

    Ok((CueSheet::new(tracks), track_metadata))
}

fn validate_wav_header(bin_path: &Path, metadata: &fs::Metadata) -> CdRomResult<()> {
    if metadata.len() < WAVE_HEADER_LEN {
        return Err(CdRomError::WaveUnsupported);
    }

    let mut header = [0; WAVE_HEADER_LEN as usize];
    let mut file = File::open(bin_path).map_err(CdRomError::DiscReadIo)?;
    file.read_exact(&mut header).map_err(CdRomError::DiscReadIo)?;

    // Format - must be 1 (PCM integer)
    let format = u16::from_le_bytes(header[20..22].try_into().unwrap());
    if format != 1 {
        return Err(CdRomError::WaveUnsupported);
    }

    // Channels - must be 2 (stereo)
    let channels = u16::from_le_bytes(header[22..24].try_into().unwrap());
    if channels != 2 {
        return Err(CdRomError::WaveUnsupported);
    }

    // Sample rate - must be 44100 Hz
    let sample_rate = u32::from_le_bytes(header[24..28].try_into().unwrap());
    if sample_rate != 44100 {
        return Err(CdRomError::WaveUnsupported);
    }

    // Bits per sample - must be 16
    let bits_per_sample = u16::from_le_bytes(header[34..36].try_into().unwrap());
    if bits_per_sample != 16 {
        return Err(CdRomError::WaveUnsupported);
    }

    Ok(())
}
